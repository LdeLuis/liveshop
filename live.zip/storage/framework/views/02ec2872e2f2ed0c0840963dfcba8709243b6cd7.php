<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<title>Administración</title>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="shortcut icon" href="<?php echo e(asset('img/design/logo-wozial.ico')); ?>">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
	<!-- Font Awsome -->
	<script src="https://kit.fontawesome.com/910783a909.js" crossorigin="anonymous"></script>

	<!-- UIkit CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.5.5/dist/css/uikit.min.css" />

	<!-- jQuery es neceario -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- UIkit JS -->
	<script src="https://cdn.jsdelivr.net/npm/uikit@3.5.5/dist/js/uikit.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/uikit@3.5.5/dist/js/uikit-icons.min.js"></script>

</head>
<body>
	<div class="uk-inline uk-width-1-1" style="min-height: 100vh;">
		<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="animation:fade; autoplay:true; autoplay-interval:3000; pause-on-hover:false;">
			<ul class="uk-slideshow-items" uk-height-viewport="min-height: 700">
				<?php
					$nums = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17];
					$nums = Arr::shuffle($nums);
				?>
				<?php $__currentLoopData = $nums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<div class="uk-position-cover">
							<img src="<?php echo e(asset('img/photos/backgrounds/bg-'.$nu.'.jpg')); ?>" alt="" uk-cover>
						</div>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
		<div class="uk-position-center" style="width:300px;">
			<div class="uk-border-rounded uk-overlay uk-overlay-default" uk-scrollspy="cls:uk-animation-slide-bottom-medium; delay:800;" style="border-radius: 26px; ">
				<div class="uk-text-center">
					<img src="<?php echo e(asset('img/design/logo-wozial.png')); ?>" class="margin-bottom-10" style="max-height: 50px;">
				</div>

				<form method="POST" action="<?php echo e(route('login')); ?>">
					<?php echo csrf_field(); ?>

					<div class="uk-inline py-0 my-0">
						<span class="uk-form-icon uk-form-icon-flip" href="" uk-icon="icon: user"></span>
						<input id="email" type="email" class="uk-input uk-margin uk-width-1-1 uk-form-large <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> uk-form-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" style="border-radius: 16px;" required autocomplete="email" autofocus>

						<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="uk-form-danger" role="alert">
										<strong><?php echo e($message); ?></strong>
								</div>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="uk-inline py-0 my-0">
						<span class="uk-form-icon uk-form-icon-flip" href="" uk-icon="icon: lock"></span>
						
						<input id="password" type="password" class="pass uk-input uk-margin uk-width-1-1 uk-form-large <?php echo e($errors->has('password') ? ' uk-form-danger' : ''); ?>" name="password" style="border-radius: 16px;" required>

						<?php if($errors->has('password')): ?>
							<span class="uk-form-danger">
								<strong><?php echo e($errors->first('password')); ?></strong>
							</span>
						<?php endif; ?>
					</div>
					<div class="col-12 d-flex justify-content-center">
                        <input type="hidden" name="from" value="1">
						<button type="submit" class="col-12 btn btn-primary" style="border-radius: 16px;">
							<?php echo e(__('Login')); ?>

					</button>
					</div>

				</form>
			</div>
		</div>
	</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\liveshop\resources\views/front/admin.blade.php ENDPATH**/ ?>