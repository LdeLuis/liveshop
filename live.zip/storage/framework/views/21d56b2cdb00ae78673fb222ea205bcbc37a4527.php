<div class="custom-pagination">
    <?php if($catalogos->onFirstPage()): ?>
        <span class="prev disabled">- PREV -</span>
    <?php else: ?>
        <a href="<?php echo e($catalogos->previousPageUrl()); ?>" class="prev pagination-link">- PREV -</a>
    <?php endif; ?>

    <?php for($i = 1; $i <= $catalogos->lastPage(); $i++): ?>
        <a href="<?php echo e($catalogos->url($i)); ?>" class="page-dot pagination-link <?php echo e($i == $catalogos->currentPage() ? 'active' : ''); ?>"></a>
    <?php endfor; ?>

    <?php if($catalogos->hasMorePages()): ?>
        <a href="<?php echo e($catalogos->nextPageUrl()); ?>" class="next pagination-link">NEXT -</a>
    <?php else: ?>
        <span class="next disabled">NEXT -</span>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\liveshop\resources\views/front/pagination.blade.php ENDPATH**/ ?>