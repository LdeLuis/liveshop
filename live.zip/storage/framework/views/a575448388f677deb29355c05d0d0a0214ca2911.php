<style>
    header{
        width: 100%;
        height: 10rem;
        display: flex;
        position: relative;
        z-index: 10;
        flex-direction: column;
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
        background-image: url(<?php echo e(asset('img/design/recursos/shape2.png')); ?>)
    }

    header .top-header{
        width: 100%;
        height: 3.5rem;
        background-color: var(--green);
        display: flex;
        justify-content: space-around;
    }

    header .top-header div:first-child{
        height: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        gap: 0.7rem;
    }

    header .top-header div:first-child .rosa{
        color: var(--pink);
        font-size: 1.2rem;
        margin: 0;
        letter-spacing: 0.2rem;
    }

    header .top-header div:first-child .blanca{
        color: var(--white);
        font-size: 1.2rem;
        margin: 0;
        letter-spacing: 0.2rem;
    }

    header .top-header div:last-child{
        height: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        gap: 1.2rem;
    }

    header .top-header div:last-child a i{
        color: var(--pink);
        font-size: 1.8rem
    }

    header .h-main{
        width: 100%;
        height: 6.5rem;
        position: relative;
        display: flex;
        justify-content: right;
        align-items: center;
        padding: 1rem 8rem;
        
    }

    header .h-main .img1{
        width: 15rem;
        left: 50%;
        position: absolute;
        bottom: 0;
        transform: translate(-50%,50%)
    }
    
    header .h-main .sesion{
        text-decoration: none;
        color: var(--green);
        font-size: 1.2rem;
    }

    header .h-main a .ico1{
        width: 3.3rem;
        margin-left: 1rem;
    }

    header .h-main a .ico2{
        width: 3.3rem;
        margin-left: 0.5rem;
    }

    header .h-main .menu-toggle{
        display: none;
    }


    /* Modal Styles */
    .menu-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7); /* Fondo oscuro */
        z-index: 9999;
        justify-content: center;
        align-items: start;
        padding-top: 20%
    }

    .menu-content {
        background-color: white;
        padding: 20px;
        text-align: center;
        width: 80%;
        max-width: 300px;
        border-radius: 8px;
    }

    .menu-content a {
        display: block;
        padding: 15px;
        color: black;
        text-decoration: none;
        font-size: 18px;
        border-bottom: 1px solid #ddd;
    }

    .menu-content a:hover {
        background-color: #f1f1f1;
    }

    .menu-content .close-btn {
        background: none;
        border: none;
        color: #000;
        font-size: 30px;
        position: absolute;
        top: 10px;
        right: 10px;
        cursor: pointer;
    }

    header .h-main .menu-toggle {
        display: none   ;
        border: none;
        background-color: transparent;
        font-size: 2.5rem;
        margin-top: 0;
    }



    @media(min-width: 576px) and (max-width: 992px) {
        header .top-header div:first-child .rosa{ 
            font-size: 0.8rem;
            letter-spacing: 0;
        }

        header .top-header div:first-child .blanca{
            font-size: 0.8rem;
            letter-spacing: 0;
        }

        header .top-header div:last-child a i{
            font-size: 1rem
        }

        header .h-main{
            padding: 1rem ;
            
        }


        header .h-main .sesion{
            font-size: 1rem;
        }

        header .h-main a .ico1{
            width: 2.3rem;
        }

        header .h-main a .ico2{
            width: 2.3rem;
        }

    }

    @media(min-width: 0px) and (max-width: 576px) {
        header .top-header div:first-child{
            display: none;
        }

        header .top-header div:last-child a i{
            font-size: 1.5rem
        }

        header .h-main{
            padding: 0.2rem 1rem ;
        }

        

        header .h-main .sesion{
            display: none;
        }

        header .h-main a .ico1{
            display: none;
        }
        header .h-main a .ico2{
            display: none;
        }

        header .h-main .menu-toggle{
            display: block;
            border: none;
            background-color: transparent;
            font-size: 2.5rem;
            margin-top: 0;

        }

        header .h-main .menu-toggle {
            display: block;
        }
        
    }

</style>

<header>
    <div class="top-header">
        <div>
            <p class="rosa">PROXIMÁ FECHA DE VENTA</p>
            <p class="blanca">EN VIVO</p>
            <p class="rosa">14 DE FEBRERO</p>
            <p class="blanca">7:00 PM</p>
            <p class="rosa">HORARIO CDMX</p>
        </div>
        <div>
            <a href=""><i class="fa-brands fa-whatsapp"></i></a>
            <a href=""><i class="fa-brands fa-instagram"></i></a>
            <a href=""><i class="fa-brands fa-facebook-f"></i></a>
        </div>
    </div>
    <div class="h-main">
        <a href="<?php echo e(route('front.home')); ?>"><img class="img1" src="<?php echo e(asset('img/design/recursos/logo.png')); ?>" alt=""></a>
       
        <a href="" class="sesion">Inicio de sesión</a>
        <a href=""><img class="ico1" src="<?php echo e(asset('img/design/recursos/user.png')); ?>" alt=""></a>
        <a href="<?php echo e(route('front.nosotros')); ?>"><img class="ico2" src="<?php echo e(asset('img/design/recursos/shop.png')); ?>" alt=""></a>
        <button class="menu-toggle">☰</button>
    </div>
</header>

<div id="menuModal" class="menu-modal">
    <div class="menu-content">
        <a href="<?php echo e(route('front.home')); ?>">Inicio</a>
        <a href="<?php echo e(route('front.nosotros')); ?>">Catalogo</a>
        <a href="">Carrito</a>
        <a href="">Usuario</a>
        <a href="">Iniciar sesión</a>
        <button class="close-btn"></button>
    </div>
</div>


<script>
    // Obtener el modal y el botón de menú
const menuModal = document.getElementById('menuModal');
const menuToggle = document.querySelector('.menu-toggle');
const closeBtn = document.querySelector('.close-btn');

// Abrir el modal al hacer clic en el botón del menú
menuToggle.addEventListener('click', () => {
    menuModal.style.display = 'flex';
});

// Cerrar el modal al hacer clic en el botón de cerrar
closeBtn.addEventListener('click', () => {
    menuModal.style.display = 'none';
});

// También cerrar el modal si el usuario hace clic fuera del menú
window.addEventListener('click', (e) => {
    if (e.target === menuModal) {
        menuModal.style.display = 'none';
    }
});

</script>


<?php /**PATH C:\xampp\htdocs\liveshop\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>