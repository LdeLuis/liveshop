<?php $__env->startSection('extraCSS'); ?>
    
    <style>
        
        .portada-img {
            width: 100%;
            height: 32rem;
            object-fit: contain;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 mb-4 px-2">
        <a href="<?php echo e(route('seccion.show', ['slug' => 'catalogo'])); ?>" class="mt-5 col col-md-2 btn btn-sm btn-dark mr-auto"><i class="fa fa-reply"></i> Regresar</a>
    </div>

    <div class="container-fluid mb-5">
        <div class="row">
            <div class="col text-center fs-1">
                Producto: <?php echo e($catalogo->nombre); ?>

            </div>
        </div>
        <div class="row">
            <div class="col">
                <form class="card py-5 rounded" style="background-color: #;">  
                    <div class="row">
                        <div class="col-9 mx-auto">
                            <div class="row">
                                <div class="col">
                                    <div class="input-group mb-3">
                                        <img src="<?php echo e(asset('img/photos/catalogo/'.$catalogo->portada)); ?>" alt="" class="img-fluid portada-img">
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="input-alto">Catálogo</span>
                                                <input disabled type="text" class="form-control" value="<?php echo e($catalogo->categoria->categoria); ?>">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="input-alto">Talla</span>
                                                <input disabled type="text" class="form-control" value="<?php echo e($catalogo->talla->talla); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-3">
                                        <span class="input-group-text" id="input-nombre">Nombre</span>
                                        <input disabled type="text" class="form-control shadow-none" aria-label="nombre" aria-describedby="input-nombre" value="<?php echo e($catalogo->nombre); ?>">
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="input-largo">Largo</span>
                                                <input disabled type="text" class="form-control shadow-none" aria-label="nombre" aria-describedby="input-largo" value="<?php echo e($catalogo->largo); ?>">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="input-ancho">Ancho</span>
                                                <input disabled type="text" class="form-control shadow-none" aria-label="nombre" aria-describedby="input-ancho" value="<?php echo e($catalogo->ancho); ?>">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="input-group mb-3">
                                                <span class="input-group-text" id="input-alto">Alto</span>
                                                <input disabled type="text" class="form-control shadow-none" aria-label="nombre" aria-describedby="input-alto" value="<?php echo e($catalogo->alto); ?>"> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="row">
                                        <?php $__empty_1 = true; $__currentLoopData = $catalogo->caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caracteristica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <input disabled type="text" value="<?php echo e($caracteristica->caracteristica); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            Este catalogo no tiene características
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
   </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>

 

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveshop\resources\views/config/secciones/catalogos/show.blade.php ENDPATH**/ ?>