<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('extracss'); ?>

    <style>

        .imagen-slider {
            width: 100%;
            object-fit: 100%;
        }

        .titulo-slider {
            font-size: 3.8rem;
            font-weight: 300;
            line-height: 1.2;
        }

        .boton-slider {
            background-color: var(--boton-verde);
            color: white;
            font-weight: bold;
            border-radius: 0;
        }

        .boton-slider:hover {
            background-color: var(--fondo-verde);
            color: white;
        }

        /* Slick personalizado 11111111111111111111111111 */
        .dots {
            position: absolute;
            bottom: 15px; 
            left: 55px;
            transform: translateX(-50%);
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .dots li {
            display: inline-block;
            margin: 0 5px;
        }

        .dots li.slick-active button {
            background-color: var(--boton-verde); 
            border: 1px solid var(--boton-verde);
        }

        .dots button {
            width: 18px;
            height: 18px;
            border-radius: 0;
            background-color: var(--blanco);
            border: 1px solid var(--blanco);
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .slick-dots li button:before {
            content: none;
        }
        /* Slick personalizado 11111111111111111111111111 */

        @media(min-width: 992px) {
            .imagen-slider { height: 52rem; }
            .titulo-slider { font-size: 3.8rem; }
        }

        @media(min-width: 576px) and (max-width: 992px) {
            .imagen-slider { height: 40rem; }
            .titulo-slider { font-size: 2.8rem; }
        }

        @media(min-width: 0px) and (max-width: 576px) {
            .imagen-slider { height: 32rem; }
            .titulo-slider { font-size: 1.8rem; }
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row px-4">
            <div class="col position-relative">
                <div class="row slider-principal">
                    <?php $__currentLoopData = $slider_principal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <img src="<?php echo e(asset('img/photos/sliders/'.$sp->imagen)); ?>" alt="Imagen" class="imagen-slider">   
                        </div>     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-xxl-6 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12 position-absolute top-0 start-0 border border-danger py-5">
                    <div class="row">
                        <div class="col-11 mx-auto">
                            <div class="row">
                                <div class="col titulo-slider">
                                    La Mejor Selección de Plantas Artificiales
                                </div>
                            </div>
                            <div class="row mt-4">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <a href="#/" class="btn w-100 py-3 boton-slider">VER CATÁLOGO</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 position-absolute bottom-0 start-0 border border-danger py-5">
                    <div class="dots"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid py-5">
        <div class="row">
            <div class="col">

            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        $('.slider-principal').slick({
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            dots: true,  
            appendDots: $('.dots'),
            customPaging: function(slider, i) {
                return '<button></button>';
            }
        });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\template\resources\views/front/index.blade.php ENDPATH**/ ?>