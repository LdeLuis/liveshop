<header>
	<?php echo $__env->make('layouts.partials_admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<style>
		.black-skin .navbar.double-nav a{
			color: #222;
		}
	</style>
	<nav class="navbar py-2 row fixed-top navbar-expand-lg scrolling-navbar mx-3 mt-1" style="z-index: 9999;box-shadow: none; background: black; color: #222; box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.291); border-radius: 16px; height: 50px;">

        <div class="row px-5">
            <div class="col-md-6 col-12 text-white text-start">
                Administrador - LIVE SHOPPING
            </div>
            <div class="col-md-6 col-12 text-white text-end">
                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="bi bi-escape"></i> <?php echo e(__('Salir del administrador')); ?>

                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>

	</nav>

</header>

<?php /**PATH C:\xampp\htdocs\liveshop\resources\views/layouts/partials_admin/header.blade.php ENDPATH**/ ?>