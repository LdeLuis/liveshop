<style>

    header {
        border-top: 5px solid var(--fondo-verde);
        border-bottom: 2px solid var(--blanco);
        background: var(--fondo-gris);
    }

    .btn-logo {
        text-decoration: none;
    }

    .link-header {
        font-size: 0.8rem;
        font-weight: 600;
        color: var(--texto-header);
        padding: 0.5rem 1.5rem;
        text-decoration: none;
    }

    .link-header:hover {
        color: var(--fondo-verde);
        border-top: 1px solid var(--fondo-verde);
        border-left: 1px solid var(--fondo-verde);
        border-right: 1px solid var(--fondo-verde);
        border-bottom: 5px solid var(--fondo-verde);
    }

    .link-header_small {
        font-size: 1.4rem;
        font-weight: 600;
        color: var(--texto-header);
        text-decoration: none;
    }

    .link-header_small:hover {
        color: var(--fondo-verde);
        border-bottom: 5px solid var(--fondo-verde);
    }

    .btn-social {
        color: var(--negro);
        text-decoration: none;
    }

    .btn-social > .bi {
        font-size: 1.4rem;
    }

    .btn-social:hover {
        color: var(--fondo-verde);
    }

    @media(min-width: 992px) {
        #menu-grande { display: block; }
        #menu-movil { display: none; }
    }

    @media(min-width: 0px) and (max-width: 992px) {
        #menu-grande { display: none; }
        #menu-movil { display: block; }
    }

</style>

<div class="container-fluid" id="menu-grande">
    <div class="row pt-4 px-4">
        <header class="col-12 mx-auto">
            <div class="row">
                <div class="col-2 text-center border py-2">
                    <div class="row">
                        <div class="col-11 mx-auto">
                            <a href="#/" class="btn-logo">
                                <img src="<?php echo e(asset('img/photos/home/capa_38_Objeto inteligente vectorial copia.png')); ?>" alt="" class="img-fluid">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-12 border py-2 mt-1">
                    <div class="row">
                        <div class="col-11 mx-auto">
                            <div class="row text-center">
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">HOME</a>
                                </div>
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">CATÁLOGO</a>
                                </div>
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">GALERÍA</a>
                                </div>
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">NOSOTROS</a>
                                </div>
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">BLOGS</a>
                                </div>
                                <div class="col-lg-2 col-12">
                                    <a href="#/" class="link-header">CONTACTO</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-2 border py-2">
                    <div class="row">
                        <div class="col-8 mx-auto">
                            <div class="row text-center">
                                <div class="col-4">
                                    <a href="#/" class="btn-social"><i class="bi bi-whatsapp"></i></a>
                                </div>
                                <div class="col-4">
                                    <a href="#/" class="btn-social"><i class="bi bi-facebook"></i></a>
                                </div>
                                <div class="col-4">
                                    <a href="#/" class="btn-social"><i class="bi bi-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    </div>
</div>

<header id="menu-movil">
    <nav class="navbar navbar-expand-full">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="<?php echo e(asset('img/photos/home/capa_38_Objeto inteligente vectorial copia.png')); ?>" alt="" class="img-fluid">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav text-center py-3">
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">HOME</a>
                    </li>
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">CATÁLOGO</a>
                    </li>
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">GALERÍA</a>
                    </li>
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">NOSOTROS</a>
                    </li>
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">BLOG</a>
                    </li>
                    <li class="nav-item py-1">
                        <a href="#/" class="link-header_small">CONTACTO</a>
                    </li>
                    <li class="nav-item py-2">
                        <div class="row text-center">
                            <div class="col-md-9 col-6 mx-auto">
                                <div class="row">
                                    <div class="col-4">
                                        <a href="#/" class="btn-social"><i class="bi bi-whatsapp"></i></a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#/" class="btn-social"><i class="bi bi-facebook"></i></a>
                                    </div>
                                    <div class="col-4">
                                        <a href="#/" class="btn-social"><i class="bi bi-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<?php /**PATH C:\xampp\htdocs\template\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>