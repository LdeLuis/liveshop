<div class="carru" id="catalogo-section">
    <?php $__currentLoopData = $catalogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($imagenesPorSeccion[$c->id])): ?>
            <?php $img = $imagenesPorSeccion[$c->id]; ?>

            <div class="tarjeta">
                <div class="imagen">
                    <img src="<?php echo e(asset('img/photos/catalogo/' . $img->imagen)); ?>" alt="">
                    <div class="detalle">
                        <a href="<?php echo e(route('front.catalogo_productos')); ?>">MAS DETALLE</a>
                        <img src="<?php echo e(asset('img/design/recursos/icono.png')); ?>" alt="">
                    </div>
                </div>
                <div class="content">
                    <h3><?php echo e($c->nombre); ?></h3>
                    <p>$<?php echo e($c->precio); ?> MXN</p>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\liveshop\resources\views/front/catalogo.blade.php ENDPATH**/ ?>