<?php $__env->startSection('extraCSS'); ?>
    <style>

        body { background-color: #e5e8eb  !important; }

        .card-header { background-color: #b0c1d1  !important; }

        .black-skin
        .btn-primary { background-color: #b0c1d1  !important; }

        .btn {
            box-shadow: none;
            border-radius: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row mt-5 mb-4 px-2">
        <a href="<?php echo e(route('front.admin')); ?>" class="mt-5 col col-md-2 btn btn-sm btn-dark mr-auto"><i class="fa fa-reply"></i> Regresar</a>
    </div>

    <div class="row pb-5">
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[0]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[0]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[0]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[1]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[1]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[1]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[2]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[2]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[2]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[3]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[3]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[3]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[4]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[4]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[4]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
        <div class="col-xxl-6 col-xl-6 col-lg-9 col-md-12 col-sm-12 col-12 mx-auto text-center my-3">
			<div class="card">
				<form action="<?php echo e(route('politicas.update', $politicas[5]->id)); ?>" method="post" class="card-body">
					<?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
					<label for="descripcion" class="fs-3 fw-bolder py-2"><?php echo e($politicas[5]->titulo); ?></label>
					<textarea class="form-control summernote" name="descripcion" id="descripcion" rows="10"><?php echo e($politicas[5]->descripcion); ?></textarea>
					<div class="form-group text-center mt-3">
						<button type="submit" class="btn btn-primary w-100 rounded-0">Guardar</button>
					</div>
				</form>
			</div>
		</div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>
	<script>
		$('.summernote').summernote({
			placeholder: 'Hello stand alone ui',
			tabsize: 2,
			height: 300,
			toolbar: [
				['style', ['style']],
				['font', ['bold', 'underline', 'clear']],
				['color', ['color']],
				['para', ['ul', 'ol', 'paragraph']],
				['table', ['table']],
			//   ['insert', ['link', 'picture', 'video']],
			//   ['view', ['fullscreen', 'codeview', 'help']]
			]
		});
	</script>
    <script>
        tinymce.init({
            selector: 'textarea',
            // plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
            // toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
                    menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table paste code help wordcount',
                        'advlist autolink lists link image charmap print preview anchor wordcount',

                        'searchreplace visualblocks code fullscreen table visualblocks',
                        'insertdatetime media table contextmenu paste code imagetools',
                        'textcolor colorpicker'
                ],
                // toolbar: 'undo redo | formatselect | ' +
                // 'bold italic backcolor | alignleft aligncenter ' +
                // 'alignright alignjustify | bullist numlist outdent indent | ' +
                // 'removeformat | help',
                    toolbar: 'forecolor backcolor | insert table | undo redo | removeformat styleselect |  bold italic underline |  alignleft aligncenter alignright alignjustify |  bullist numlist | outdent indent | link image | code visualblocks',
                    resize: false,
                content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }'
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveshop\resources\views/config/politicas/index.blade.php ENDPATH**/ ?>