@extends('layouts.admin')

@section('extraCSS')
    


@endsection

@section('content')
    <div class="row mt-5 mb-4 px-2">
        <a href="{{ route('seccion.show', ['slug' => 'blogs']) }}" class="mt-5 col col-md-2 btn btn-sm btn-dark mr-auto"><i class="fa fa-reply"></i> Regresar</a>
    </div>

    

@endsection

@section('extraJS')
    
    

@endsection


